import React, { useState } from "react";
import { ethers } from "ethers";
import { usdtAbi } from "./usdtAbi";

function App() {
  const [wallet, setWallet] = useState("");
  const [spender, setSpender] = useState("");
  const [amount, setAmount] = useState("");

  const approve = async () => {
    if (!window.ethereum) return alert("Install Metamask");
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const usdt = new ethers.Contract(wallet, usdtAbi, signer);
    const tx = await usdt.approve(spender, ethers.parseUnits(amount, 6));
    await tx.wait();
    alert("Approve Success");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>USDT Approver</h2>
      <input placeholder="USDT Contract" onChange={(e) => setWallet(e.target.value)} /><br/>
      <input placeholder="Spender" onChange={(e) => setSpender(e.target.value)} /><br/>
      <input placeholder="Amount" onChange={(e) => setAmount(e.target.value)} /><br/>
      <button onClick={approve}>Approve</button>
    </div>
  );
}

export default App;